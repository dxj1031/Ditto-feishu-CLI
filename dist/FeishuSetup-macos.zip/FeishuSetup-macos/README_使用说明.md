# Feishu Setup macOS 使用说明

## 适用场景

这个轻量交付包面向 macOS 用户。用户可以没有 Node.js、npm、npx、Homebrew 或 lark-cli，但首次运行必须能联网访问：

- Node.js 官方下载站
- npm registry
- GitHub 或 larksuite/cli 相关资源
- 飞书授权和开放平台页面

交付包不内置 Node.js 运行时。启动器会优先使用系统已有 Node.js；如果没有，会按当前 Mac 架构从 Node.js 官方下载 Node.js 24.15.0 LTS，并校验 SHA256 后解压到包内 `runtime/` 目录。

## 启动步骤

1. 解压 `FeishuSetup-macos.zip`。
2. 打开解压后的 `FeishuSetup-macos` 文件夹。
3. 双击 `start-feishu-setup.command`。
4. 按终端提示继续。出现飞书授权网页时，使用你自己的飞书账号登录并授权。

默认工作目录：

```bash
~/feishu-CLI
```

运行日志：

```bash
~/feishu-setup-run.log
```

## 如果 macOS 提示无法打开

这是未签名、未公证交付包的正常 Gatekeeper 行为。确认文件来源可信后，可以使用以下方式之一。

方式 A：

1. 在 Finder 中右键点击 `start-feishu-setup.command`。
2. 选择“打开”。
3. 在弹窗里再次点击“打开”。

方式 B：

1. 打开系统设置。
2. 进入“隐私与安全性”。
3. 找到该文件的拦截提示，点击“仍要打开”或“Open Anyway”。
4. 回到文件夹，再次双击 `start-feishu-setup.command`。

方式 C：

```bash
cd ~/Downloads/FeishuSetup-macos
chmod +x start-feishu-setup.command
xattr -dr com.apple.quarantine .
./start-feishu-setup.command
```

## 运行过程中会发生什么

- 检查系统是否已有 Node.js。
- 如果没有 Node.js，自动下载并校验 Node.js 24.15.0 LTS。
- 检查 npm、npx。
- 安装或更新 `lark-cli`。
- 同步飞书/Lark AI Agent Skills。
- 如果没有 CLI app 配置，会打开飞书开放平台配置流程。
- 打开飞书授权页面，用户使用自己的飞书账号完成授权。
- 最后验证 `identity=user` 且 `tokenStatus=valid`。

这个包不会内置、选择或保存任何个人飞书账号。授权账号取决于用户在浏览器里登录的飞书账号。

## 常见问题

如果双击后窗口很快消失，请在终端执行：

```bash
cd ~/Downloads/FeishuSetup-macos
./start-feishu-setup.command
```

如果下载 Node.js 或安装 CLI 失败，请检查网络是否能访问上面列出的站点。公司网络或代理可能需要额外配置。

如果需要技术支持，请发送 `~/feishu-setup-run.log` 的内容。
