# FeishuSetup-macos 轻量交付包说明

## 交付物

最终交付 zip：

```text
dist/FeishuSetup-macos.zip
```

解压后目录：

```text
FeishuSetup-macos/
  start-feishu-setup.command
  README_使用说明.md
  README_DELIVERY.md
  app/
    setup-core.mjs
    terminal-setup.mjs
```

## 设计取舍

这个版本不把 Node.js tarball 或其它前置依赖包放进交付 zip。这样交付物体积小，便于发送和入库。

代价是首次运行需要联网。启动器会：

1. 优先复用系统已有 Node.js。
2. 如果没有 Node.js，按 `uname -m` 判断 Apple Silicon 或 Intel。
3. 从 Node.js 官方下载 Node.js 24.15.0 LTS macOS tarball。
4. 用内置 SHA256 值校验下载内容。
5. 解压到本包 `runtime/` 目录后继续执行 setup。

## 未签名运行结论

无需签名也可以做内部测试交付，但不能保证用户第一次直接双击就无提示通过。macOS Gatekeeper 对下载的软件会做首次打开校验；未签名、未公证时，用户通常需要右键“打开”、系统设置里“仍要打开”，或由技术支持执行：

```bash
xattr -dr com.apple.quarantine .
```

面向大规模非技术用户分发时，仍建议做 Developer ID 签名和 Apple notarization。

参考：

- Apple Gatekeeper 说明：https://support.apple.com/guide/security/gatekeeper-and-runtime-protection-sec5599b66df/web
- Apple 安全打开 App 说明：https://support.apple.com/en-gb/102445
- Apple Xcode 外部分发说明：https://help.apple.com/xcode/mac/current/en.lproj/dev033e997ca.html

## Node.js 下载

首次运行按架构下载以下文件之一：

- https://nodejs.org/dist/v24.15.0/node-v24.15.0-darwin-arm64.tar.gz
- https://nodejs.org/dist/v24.15.0/node-v24.15.0-darwin-x64.tar.gz

启动器内置 SHA256：

```text
372331B969779AB5D15B949884FC6EAF88D5AFE87BDE8BA881D6400B9100FFC4 node-v24.15.0-darwin-arm64.tar.gz
FFD5EE293467927F3EE731A553EB88FD1F48CF74EEBC2D74A6BABE4AF228673B node-v24.15.0-darwin-x64.tar.gz
```

## CI 测试

`.github/workflows/test-macos.yml` 使用 `macos-latest` 验证：

- `dist/FeishuSetup-macos.zip` 小于 1 MB。
- `.command` 可执行位、shebang、LF、BOM 检查。
- zip 内不包含 Node runtime tarball。
- 模拟 `com.apple.quarantine` 属性并确认启动器会清理该属性。
- 强制走首次 Node 下载路径，确认下载、校验、解压成功。
- 使用 mock `npm`、`npx`、`lark-cli`、`open` 跑完整 setup 主流程，不需要真实飞书账号或交互式浏览器授权。
- 上传 `start-run.log`、`final-summary.txt` 和 `~/feishu-setup-run.log`。

注意：CI 不是 Finder 图形界面双击测试，但它是真实 macOS runner，能覆盖 shell 启动、quarantine 属性、下载解压、CLI 主流程和日志结果。
